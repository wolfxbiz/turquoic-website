'use client'

import { useRef } from 'react'
import { motion, useInView } from 'framer-motion'
import { Star } from 'lucide-react'
import { staggerContainer, fadeUp } from '@/lib/animations'
import config from '@/_config'

export default function Testimonials() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-10% 0px' })
  const { sectionLabel, heading, overallRating, items } = config.testimonials

  return (
    <section id="testimonials" className="bg-teal-light py-24 lg:py-32">
      <div className="max-w-7xl mx-auto px-6 lg:px-8" ref={ref}>
        <motion.div className="flex items-center gap-3 mb-4 justify-center" initial={{ opacity: 0 }} animate={isInView ? { opacity: 1 } : undefined} transition={{ duration: 0.6 }}>
          <span className="inline-block w-6 h-px bg-teal-accent" />
          <span className="text-xs font-body font-normal uppercase tracking-[0.15em] text-teal-accent">{sectionLabel}</span>
          <span className="inline-block w-6 h-px bg-teal-accent" />
        </motion.div>

        <motion.h2 className="font-display font-normal text-[clamp(28px,4vw,52px)] text-dark leading-tight uppercase text-center mb-6" initial={{ opacity: 0, y: 30 }} animate={isInView ? { opacity: 1, y: 0 } : undefined} transition={{ duration: 0.7, ease: 'easeOut' }}>
          {heading}
        </motion.h2>

        <motion.div className="flex justify-center mb-14" initial={{ opacity: 0 }} animate={isInView ? { opacity: 1 } : undefined} transition={{ delay: 0.3, duration: 0.6 }}>
          <div className="inline-flex items-center gap-2 bg-white rounded-full px-4 py-2 shadow-[0_4px_16px_rgba(45,212,192,0.12)]">
            <Star className="w-4 h-4 text-teal-strong fill-teal-strong" />
            <span className="font-body font-normal text-dark text-sm">{overallRating}</span>
            <span className="font-body text-muted text-sm">overall rating</span>
          </div>
        </motion.div>

        <motion.div className="grid grid-cols-1 md:grid-cols-3 gap-5" variants={staggerContainer} initial="hidden" animate={isInView ? 'visible' : 'hidden'}>
          {items.map((t, i) => (
            <motion.div key={i} variants={fadeUp} className="bg-white rounded-2xl p-7 shadow-[0_4px_32px_rgba(45,212,192,0.10)] border border-teal-mid/40 flex flex-col">
              <div className="flex gap-1 mb-4">
                {Array.from({ length: t.rating }).map((_, j) => (
                  <Star key={j} className="w-[13px] h-[13px] text-teal-strong fill-teal-strong" />
                ))}
              </div>
              <p className="font-body text-dark text-[14px] leading-relaxed mb-6 flex-1">&ldquo;{t.quote}&rdquo;</p>
              <div className="border-t border-teal-light/60 my-4" />
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full ring-2 ring-teal-mid/40 bg-teal-light flex items-center justify-center">
                  <span className="font-display font-normal text-sm text-teal-accent">{t.initials}</span>
                </div>
                <div>
                  <p className="font-body font-normal text-dark text-sm">{t.name}</p>
                  <p className="font-body text-teal-accent text-xs">{t.flag} {t.country}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}
